<?php session_start() ?>
<html>
  <head>
    <title> Administrator Page </title>
     <div id="section">
                
                <div><a href="homepage.html"><img src="title.png" alt="" /></a></div>
                
            </div>

<hr>




   <h1 style= "color:white;"  >Welcome Admin</h1>

 <head>
  <style>
    body {
	  font-family:arial;
	  background-color : steelblue;
	  color:white;
	 };
	</style>
<body><br>
 <h1 align="center">
  Welcome To Assesment Exam Administrator Page </h1>

                                                       
<a href="del.php">
<img border="0" alt="exam editor.png" src="exam editor.png" style="width:350px;height:200px;margin-left:15px;">

  
 <a href="studentprof.php">
<img border="0" alt="Examinee List.png" src="ExamineeList.png" style="width:350px;height:200px;margin-left:15px;" >

  

    <a href="reg.php">
<img border="0" alt="reg.png" src="reg.png" style="width:350px;height:200px;margin-left:20px;" >




     <a href="inquiry.php">
<img border="0" alt="studentInquiry.png" src="studentInquiry.png" width="300" height="300"  style="width:350px;height:200px;margin-left:15px;">

    <a href="settings.php">
<img border="0" alt="settings.png" src="settings.png" width="300" height="300"  style="width:350px;height:200px;margin-left:15px;">

 <a href="register.php">
<img border="0" alt="Acc.png" src="Acc.png" style="width:350px;height:200px;margin-left:20px;" >

<a href="resultsview.php">
<img border="0" alt="Examres.png" src="Examres.png" style="width:350px;height:200px;margin-left:20px;" >


       


<div>
<?php session_destroy(); ?>
<a href="adminlogin.php" class="button">Logout</a>
    
<style>
    
    .button {
    background-color: gold;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    float: right;



}





    
</style>





 
 </body>
 </html>
 
 

	
 
 