<?php session_start() ?>
<html>
  <head>
    <title> Registrar Page </title>
 <head>
             <div><a href="homepage.html"><img src="title.png" alt="" /></a></div>
                
            </div>

<hr>




   <h1 style= "color:white;">Welcome Registrar</h1>

 <head>
  <style>
    body {
    font-family:arial;
    background-color : steelblue;
    color:white;
   };
  </style>
<body><br>
 <h1 align="center">
  Welcome To Registrar Page</h1>



     <a href="reg.php">
<img border="0" alt="reg.png" src="reg.png" style="width:350px;height:200px;margin-left:20px;" >



     <a href="inquiry.php">
<img border="0" alt="studentInquiry.png" src="studentInquiry.png" width="300" height="300"  style="width:350px;height:200px;margin-left:15px;">

<a href="adminlogin.php" class="button">Logout</a>




<style>
    
    .button {
    background-color: gold;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    float: right;



}





    
</style>


 </body>

 </html>
 
 

	
 
 