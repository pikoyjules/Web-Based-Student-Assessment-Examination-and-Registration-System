<html>
  <head>
<body>
<body style="background-color:steelblue;">
    <a href="juniorreg.php">
<img border="0" alt="Junior Registration.png" src="Junior Registration.png" style="width:300px;height:300px;margin-left:20px;" >


    <a href="seniorreg.php">
<img border="0" alt="Senior Registration.png" src="Senior Registration.png" width="300" height="300" style="width:300px;height:300px;margin-left:20px;">

<style>
    
    .button {
    background-color: gold;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    float: right;



}





    
</style>



</body>
</head>
</html>