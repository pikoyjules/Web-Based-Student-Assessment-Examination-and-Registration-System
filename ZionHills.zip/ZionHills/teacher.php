<html>
  <head>
    <title> Teacher Page </title>
 <head>
  <style>
    body {
	  font-family:arial;
	  background-color : steelblue;
	  color:white;
	 };
	</style>

  <div><a href="homepage.html"><img src="title.png" alt="" /></a></div>
                
            </div>

<hr>
<h1 style= "color:white;"  >Welcome Admin</h1>
 <center><h1 style= "color:white;"  >Department Head Page</h1></center>
              
<body><br>
  



 


<a href="del.php">
<img border="0" alt="exam editor.png" src="exam editor.png" style="width:350px;height:200px;margin-left:15px;">


<a href="adminlogin.php" class="button">Logout</a>

<style>

    
    .button {
    background-color: gold;
    border: none;
    color: black;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    float: right;



}


    
</style>




 </body>
 </html>
 
 

	
 
 